import java.util.Scanner;
import java.util.Scanner.*;
import java.io.FileReader;
import java.io.FileReader.*;
import java.io.*;
import java.util.*;
import java.io.IOException;
import java.util.ArrayList;



public interface CarbonFootprint {
	  public double getCarbonFootprint();
}//CarbonFootprint